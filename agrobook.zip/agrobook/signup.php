<?php
$conn = mysqli_connect("localhost", "root", "", "strings") or die("Error : " . mysqli_error($conn));

if (isset($_POST['add'])) {
  $Name = $_POST['name'];
  $Email = $_POST['email'];
  $Password = $_POST['password'];
  $insert = "insert into sign(name, email, password) values('$Name','$Email','$Password')";
  if (mysqli_query($conn, $insert)) {
    echo "<script>alert('success')</script>";
  } else {
    echo "<script>alert('error')</script>";
    die("Error : " . mysqli_error($conn));
  }
}
function check(){
    global $conn;
    $amm = array();
    $total = 0;
    $sql = "select name from sign";
    $amma = "select email from sign";
    $name = trim($_GET['passwor']);
    $email = trim($_GET['emai']);
    if(empty($name) || empty($email)){
        $msg_type = "danger";
        $msg = "All Fields are required!";
    }

    // $res = mysqli_query($conn, $sql, $amma) or die (mysqli_error($conn));
    if($sql == $name){
        echo "<script>alert('You are welcome back')</script>";
    }
    else{
        echo "<script>alert('please sign up first')</script>";
    die("Error : " . mysqli_error($conn));
    }
    if($amma == $email){
        echo "<script>alert('You are welcome back')</script>";
    }
    else{
        echo "<script>alert('please sign up first')</script>";
        die("Error : " . mysqli_error($conn));
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-up</title>
    <link rel="stylesheet" href="./sign.css">
</head>
<body>
    <div class="container">
        <h3>Welcome!</h3>
        <h4>Please register below</h4>
        <form action="./upload.php" method="POST" enctype="multipart/form-data">
            <div class="na">
            <label for="text">Name</label>
            <input type="text" name="name" class="name" placeholder="Name" required/>
            </div>
            <div class="e">
                <label for="text">Email</label>
                <input type="text" name="email" class="email" placeholder="E-mail" required/>
            </div>
           <div class="p">
               <label for="text">Password</label>
               <input type="password" name="password" class="password" placeholder="Password" required/>
           </div>
           <button name="add">Sign-Up</button>
        </form>
        <div class="move">
            <span>Already have an account?</span> <span class="s" onclick="signup()">Sign-in</span>
        </div>
        
    </div>


    <div class="container2">
        <h3>Welcome Back!</h3>
        <form action="./upload.php" method="POST" enctype="multipart/form-data">
        <div class="em">
                <label for="text">Email</label>
                <input type="text" name="emai" class="email" placeholder="E-mail" required/>
            </div>
           <div class="pa">
               <label for="text">Password</label>
               <input type="password" name="passwor" class="password" placeholder="Password" required/>
           </div>
           <a href="./xplaindash.php"><button name="up" onclick="check()">Sign-Up</button></a>
        </form>
    </div>
    <!-- <div class="img">
        <img src="./DJI-Agras-MG-1S.jpg" alt="wall">
    </div> -->

</body>
<script>
    let add = document.querySelector(".container2");
    function signup(){
        add.style.display="block";
    }
</script>
</html>