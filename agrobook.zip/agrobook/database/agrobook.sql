-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2022 at 09:26 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrobook`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Id` int(11) NOT NULL,
  `Name` varchar(35) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Subject` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Id`, `Name`, `Email`, `Description`, `Subject`) VALUES
(1, 'Popoola Rofih', 'popoolarofih@gmail.c', '', 'Vendor'),
(2, 'Oyindamola Tishe', 'tishe@gmail.com', '', 'Vendor'),
(3, 'Sanni Uswat', 'sanniuswat@gmail.com', 'Nice Tractor', 'Tractor');

-- --------------------------------------------------------

--
-- Table structure for table `cynthia`
--

CREATE TABLE `cynthia` (
  `Id` int(11) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Number` varchar(30) NOT NULL,
  `Img` varchar(255) NOT NULL,
  `Address` varchar(225) NOT NULL,
  `Equipment_Name` varchar(20) NOT NULL,
  `Per_Hour_Rate` bigint(12) NOT NULL,
  `Per_Day_Rate` bigint(12) NOT NULL,
  `Leasing` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cynthia`
--

INSERT INTO `cynthia` (`Id`, `Name`, `Description`, `Email`, `Number`, `Img`, `Address`, `Equipment_Name`, `Per_Hour_Rate`, `Per_Day_Rate`, `Leasing`) VALUES
(13, 'Popooola Rofih Abiola', 'this equipment is a nice tractor', 'popoolarofih@gmail.com', '09056675341', 'South-Africa-Agricultural-Equipment-Market.jpg', 'Apata, Ibadan, Oyo state', 'Tractor', 5000, 15000, 16000);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Id` int(11) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `DOB` date NOT NULL,
  `Number` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Id`, `Name`, `Email`, `DOB`, `Number`) VALUES
(1, 'Popoola Rofih', 'popoolarofih@gmail.com', '2022-02-23', '2147483647');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `cynthia`
--
ALTER TABLE `cynthia`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cynthia`
--
ALTER TABLE `cynthia`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
