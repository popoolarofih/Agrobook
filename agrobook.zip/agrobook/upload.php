<?php 
$conn = mysqli_connect("localhost", "root", "", "agrobook") or die("Error : " . mysqli_error($conn));

if (isset($_POST['go'])) {
  $name = $_POST['full'];
  $email = $_POST['email'];
  $number = $_POST['number'];
  $describ = $_POST['description'];
  $out = $_POST['lease'];
  $equip = $_POST['name'];
  $per = $_POST['day'];
  $rate = $_POST['hour'];
  $adress = $_POST['Address'];
  $img = $_FILES['img']['name'];

  $dir = "img/";
  move_uploaded_file($_FILES['img']['tmp_name'], $dir . $img);

  $insert = "insert into cynthia(Name, Description, Email, Img, Number, Address, Equipment_Name, Per_Hour_Rate, Per_Day_Rate, Leasing ) values('$name', '$describ', '$email', '$img', '$number', '$adress', '$equip', '$rate', '$per', '$out' )";
  if (mysqli_query($conn, $insert)) {
    echo "<script>alert('Upload successful')</script>";
  } else {
    echo "<script>alert('error')</script>";
    
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Your Equipment</title>
    <link rel="stylesheet" href="./css/upload.css">
</head>
<body>

    <h2>Upload Your Equipment For Rentage</h2>
    <div class="form">
       <form action="upload.php" method="POST" enctype="multipart/form-data">
        <label for="text">
            <h3>Full Name</h3>
            <input type="text" name="full" placeholder="Full Name" required/>
        </label>
        <label for="text">
            <h3>Phone Number</h3>
            <input type="tel" name="number" placeholder="Phone Number" required/>
        </label>
        <label for="text">
            <h3>Email</h3>
            <input type="email" name="email" placeholder="Email" required/>
        </label>
        <label for="text">
            <h3>Name of Equipment</h3>
            <input type="text" name="name" placeholder="Equipment Name" required/>
        </label>
        <label for="text">
            <h3>Per Hour Rate</h3>
            <input type="number" name="hour" placeholder="Per Hour Rate" required/>
        </label>
        <label for="text">
            <h3>Per Day Rate</h3>
            <input type="number" name="day" placeholder="Per Day Rate" required/>
        </label>
        <label for="text">
            <h3>Leasing Amount</h3>
            <input type="number" name="lease" placeholder="Leasing Amount" required/>
        </label>
        <label for="text">
            <h3>Upload The Equipment Picture</h3>
            <input type="file" name="img" class="file" placeholder="Picture" accept="image/*" required/>
        </label>
        <label for="text">
            <h3>Equipment Description</h3>
            <textarea name="description" ></textarea>
        </label>
        <label for="text">
            <h3>Address</h3>
            <textarea name="Address" ></textarea>
        </label>
        <button name="go" class="btn">Upload</button>

    </form> 
    </div>
    <div class="ba">
        <span><a href="./pricing.php"><</a></span>
        <span><a href="./contact.php">></a></span> 
    </div>
</body>
</html>